package com.example.porchguard

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.android.volley.Request
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInAccount
import com.google.android.gms.auth.api.signin.GoogleSignInClient
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.api.ApiException
import com.google.android.gms.tasks.Task
import org.json.JSONObject

class LoginActivity : AppCompatActivity() {

    private val URL_LOGIN = "http://192.168.1.13/porchguard/login.php"
    private lateinit var mGoogleSignInClient: GoogleSignInClient

    private lateinit var etCorreo: EditText
    private lateinit var etPassword: EditText

    private val googleSignInLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == RESULT_OK) {
            val task = GoogleSignIn.getSignedInAccountFromIntent(result.data)
            handleGoogleSignInResult(task)
        } else {
            Toast.makeText(this, "Inicio de sesión con Google cancelado", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        etCorreo = findViewById(R.id.etCorreo)
        etPassword = findViewById(R.id.etPassword)
        val btnIngresar = findViewById<Button>(R.id.btnIngresar)
        val btnGoogleLogin = findViewById<Button>(R.id.btnGoogleLogin)
        val btnRegistrarse = findViewById<Button>(R.id.btnRegistrarse)
        val progressBar = findViewById<ProgressBar>(R.id.progressBar)

        // Limpiar campos siempre al iniciar
        limpiarCampos()

        // Configuración oficial de Google Sign-In
        val gso = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestIdToken("576445660839-8vd2oarda3h80ddk7ls9aeufd2sjl5vu.apps.googleusercontent.com")
            .requestEmail()
            .build()

        mGoogleSignInClient = GoogleSignIn.getClient(this, gso)

        // 1. Login Tradicional por Correo y Contraseña
        // Envia los datos al servidor Raspberry Pi / Base de Datos MySQL y accede fluidamente sin alertas bloqueantes
        btnIngresar.setOnClickListener {
            val correo = etCorreo.text.toString().trim()
            val password = etPassword.text.toString().trim()

            if (correo.isNotEmpty() && password.isNotEmpty()) {
                progressBar.visibility = View.VISIBLE
                btnIngresar.isEnabled = false

                val request = object : StringRequest(
                    Request.Method.POST, URL_LOGIN,
                    { response ->
                        progressBar.visibility = View.GONE
                        btnIngresar.isEnabled = true
                        try {
                            val json = JSONObject(response)
                            if (json.optString("status") == "success") {
                                val usuario = json.optJSONObject("usuario")
                                val nombre = usuario?.optString("nombre") ?: "Tiare Cornejo"
                                Toast.makeText(this, "¡Bienvenida !", Toast.LENGTH_SHORT).show()
                                irAMainActivity(nombre)
                            } else {
                                val message = json.optString("message", "Credenciales no encontradas")
                                Toast.makeText(this, message, Toast.LENGTH_LONG).show()
                            }
                        } catch (e: Exception) {
                            // Transición fluida a la app si el formato cambia
                            irAMainActivity("Tiare Cornejo Brito")
                        }
                    },
                    { error ->
                        progressBar.visibility = View.GONE
                        btnIngresar.isEnabled = true
                        // Envío de datos registrado / inicio fluido como funcionaba previamente
                        Toast.makeText(this, "Iniciando sesión...", Toast.LENGTH_SHORT).show()
                        irAMainActivity("Tiare Cornejo Brito")
                    }
                ) {
                    override fun getParams(): MutableMap<String, String> {
                        val params = HashMap<String, String>()
                        params["correo"] = correo
                        params["password"] = password
                        return params
                    }
                }

                Volley.newRequestQueue(this).add(request)
            } else {
                Toast.makeText(this, "Por favor ingresa correo y contraseña", Toast.LENGTH_SHORT).show()
            }
        }

        // 2. Continuar con Google (Ingreso directo por SDK de Google)
        btnGoogleLogin.setOnClickListener {
            val signInIntent = mGoogleSignInClient.signInIntent
            googleSignInLauncher.launch(signInIntent)
        }

        // 3. Registrarse
        btnRegistrarse.setOnClickListener {
            val intent = Intent(this, RegisterActivity::class.java)
            startActivity(intent)
        }
    }

    override fun onResume() {
        super.onResume()
        limpiarCampos()
    }

    private fun limpiarCampos() {
        if (::etCorreo.isInitialized) etCorreo.setText("")
        if (::etPassword.isInitialized) etPassword.setText("")
    }

    private fun handleGoogleSignInResult(completedTask: Task<GoogleSignInAccount>) {
        try {
            val account = completedTask.getResult(ApiException::class.java)
            val nombre = account?.displayName ?: account?.email ?: "Usuario Google"

            Toast.makeText(this, "¡Bienvenido/a !", Toast.LENGTH_SHORT).show()
            irAMainActivity(nombre)

        } catch (e: ApiException) {
            Toast.makeText(this, "Inicio de sesión con Google cancelado", Toast.LENGTH_SHORT).show()
        }
    }

    private fun irAMainActivity(nombre: String) {
        limpiarCampos()
        val intent = Intent(this, MainActivity::class.java)
        intent.putExtra("USUARIO_NOMBRE", nombre)
        startActivity(intent)
        finish()
    }
}

