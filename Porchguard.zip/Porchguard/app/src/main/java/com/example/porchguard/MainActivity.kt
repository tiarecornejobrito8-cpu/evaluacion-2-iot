package com.example.porchguard

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.provider.Settings
import android.text.InputType
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.android.volley.Request
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import com.google.android.material.chip.Chip
import java.text.SimpleDateFormat
import java.util.Date
import java.util.HashMap
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private var urlBaseServer = "http://192.168.1.13/porchguard"
    private var tokenCasilleroActual = "PG-104-A8F3"
    private var idCasillero = "104"

    private val CHANNEL_ID = "porchguard_notifications_channel"
    private val CAMERA_REQUEST_CODE = 102

    private var modoTermicoActivo = true
    private var esCerraduraAbierta = false
    private var esWifiConectado = true
    private var paqueteEnCasillero = true

    // Parámetros de Configuración
    private var pinUsuarioLocal = "1234"
    private val PIN_MAESTRO_CONSERJE = "9999"
    private var tiempoAutoCierreSegundos = 5
    private var tempMetaComidaCaliente = 40.0
    private var tempMetaRefrigerado = 8.0

    private lateinit var sharedPreferences: SharedPreferences
    private val listaNotificaciones = ArrayList<String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        sharedPreferences = getSharedPreferences("PorchGuardPrefs", Context.MODE_PRIVATE)
        pinUsuarioLocal = sharedPreferences.getString("PIN_USUARIO_LOCAL", "1234") ?: "1234"
        tiempoAutoCierreSegundos = sharedPreferences.getInt("TIEMPO_AUTOCIERRE", 5)

        crearCanalNotificaciones()
        pedirPermisosIniciales()

        val tvBienvenida = findViewById<TextView>(R.id.tvBienvenida)
        val tvEstadoVinculacion = findViewById<TextView>(R.id.tvEstadoVinculacion)
        val tvEstadoPaquete = findViewById<TextView>(R.id.tvEstadoPaquete)
        val chipPaquete = findViewById<Chip>(R.id.chipPaquete)
        val btnSimularPaquete = findViewById<Button>(R.id.btnSimularPaquete)
        val tvEstadoCerradura = findViewById<TextView>(R.id.tvEstadoCerradura)
        val tvPinUsuario = findViewById<TextView>(R.id.tvPinUsuario)
        val tvPinConserje = findViewById<TextView>(R.id.tvPinConserje)
        val tvTemperatura = findViewById<TextView>(R.id.tvTemperatura)
        val tvHumedad = findViewById<TextView>(R.id.tvHumedad)
        val tvEstadoCalefactor = findViewById<TextView>(R.id.tvEstadoCalefactor)
        val tvEstadoSeguridadLDR = findViewById<TextView>(R.id.tvEstadoSeguridadLDR)

        val btnMenuDesplegable = findViewById<Button>(R.id.btnMenuDesplegable)
        val btnVincularQR = findViewById<Button>(R.id.btnVincularQR)
        val btnAbrirBuzon = findViewById<Button>(R.id.btnAbrirBuzon)
        val btnCambiarPinUsuario = findViewById<Button>(R.id.btnCambiarPinUsuario)
        val btnGenerarPinRepartidor = findViewById<Button>(R.id.btnGenerarPinRepartidor)
        val btnToggleModoTermico = findViewById<Button>(R.id.btnToggleModoTermico)
        val btnResetAlarma = findViewById<Button>(R.id.btnResetAlarma)
        val btnCerrarSesion = findViewById<Button>(R.id.btnCerrarSesion)

        val nombreUsuario = intent.getStringExtra("USUARIO_NOMBRE") ?: "Tiare Cornejo"
        tvBienvenida.text = "¡Hola, $nombreUsuario!"
        tvPinUsuario.text = "💡 PIN Usuario Teclado Físico: $pinUsuarioLocal"
        tvPinConserje.text = "🛡️ PIN Conserjería (Maestro Único): $PIN_MAESTRO_CONSERJE"

        actualizarEstadoWifiUI(tvEstadoVinculacion, false)

        registrarYNotificar("Conexión Wi-Fi establecida con el casillero #$idCasillero.")
        registrarYNotificar("Paquete guardado dentro del casillero.")

        // 🎯 MENÚ DESPLEGABLE PRINCIPAL
        btnMenuDesplegable.setOnClickListener {
            mostrarMenuDesplegableOpciones(tvEstadoVinculacion, tvPinUsuario, nombreUsuario)
        }

        // Acceso directo Escanear QR / Vincular
        btnVincularQR.setOnClickListener {
            mostrarOpcionesVinculacionMenu(tvEstadoVinculacion)
        }

        // Toggle Estado Paquete
        btnSimularPaquete.setOnClickListener {
            paqueteEnCasillero = !paqueteEnCasillero
            actualizarEstadoPaqueteUI(tvEstadoPaquete, chipPaquete, true)
        }

        // Modificar PIN Usuario
        btnCambiarPinUsuario.setOnClickListener {
            mostrarDialogoCambiarPinUsuario(tvPinUsuario)
        }

        // Acción 1: Abrir / Cerrar Buzón por Wi-Fi (Registra en auditoria_eventos_seguridad)
        btnAbrirBuzon.setOnClickListener {
            if (!esWifiConectado) {
                Toast.makeText(this, "🔴 Imposible abrir: Casillero Desconectado", Toast.LENGTH_LONG).show()
                return@setOnClickListener
            }
            esCerraduraAbierta = !esCerraduraAbierta
            if (esCerraduraAbierta) {
                tvEstadoCerradura.text = "🔓 DESBLOQUEADO (ABIERTO)"
                tvEstadoCerradura.setTextColor(Color.parseColor("#34D399"))
                btnAbrirBuzon.text = "Bloquear Buzón"
                registrarYNotificar("¡Apertura remota concedida! Puedes retirar tu paquete.")
                enviarComandoApi("$urlBaseServer/api_unlock.php", "APERTURA_REMOTA_WIFI", "Apertura registrada en MySQL")
            } else {
                tvEstadoCerradura.text = "🔒 CERRADO Y SEGURO"
                tvEstadoCerradura.setTextColor(Color.parseColor("#F87171"))
                btnAbrirBuzon.text = "Abrir por Wi-Fi"
                registrarYNotificar("Buzón bloqueado de forma segura.")
                enviarComandoApi("$urlBaseServer/api_unlock.php", "BLOQUEO_REMOTO_WIFI", "Cierre registrado en MySQL")
            }
        }

        // Acción 2: Generar PIN Temporal para Repartidores (Registra en pins_temporales)
        btnGenerarPinRepartidor.setOnClickListener {
            val pinRandom = (1000..9999).random().toString()
            Toast.makeText(this, "🔑 Tu PIN Temporal es: $pinRandom (Válido 15 min)", Toast.LENGTH_LONG).show()
            registrarYNotificar("PIN temporal generado ($pinRandom) para el repartidor.")

            // Guardar en tabla pins_temporales en MySQL
            guardarPinTemporalEnBD(pinRandom)
        }

        // Acción 3: Cambiar Modo Térmico (Registra en historial_telemetria)
        btnToggleModoTermico.setOnClickListener {
            modoTermicoActivo = !modoTermicoActivo
            if (modoTermicoActivo) {
                tvEstadoCalefactor.text = "🔥 Calefactor Encendido"
                tvEstadoCalefactor.setTextColor(Color.parseColor("#F97316"))
                tvTemperatura.text = "🌡️ 38.5 °C"
                Toast.makeText(this, "🍕 Modo Comida Caliente Activado (35°C - 50°C)", Toast.LENGTH_SHORT).show()
                registrarYNotificar("Modo comida caliente activado a 38.5°C.")
            } else {
                tvEstadoCalefactor.text = "❄️ Modo Refrigerado"
                tvEstadoCalefactor.setTextColor(Color.parseColor("#38BDF8"))
                tvTemperatura.text = "🌡️ 8.2 °C"
                Toast.makeText(this, "❄️ Modo Refrigerado Activado (4°C - 12°C)", Toast.LENGTH_SHORT).show()
                registrarYNotificar("Modo refrigerado activado a 8.2°C.")
            }
            sincronizarTelemetriaConBD()
        }

        // Acción 4: Silenciar Alarma (Registra en auditoria_eventos_seguridad)
        btnResetAlarma.setOnClickListener {
            tvEstadoSeguridadLDR.text = "🛡️ Casillero Seguro y Protegido"
            tvEstadoSeguridadLDR.setTextColor(Color.parseColor("#38BDF8"))
            enviarComandoApi("$urlBaseServer/api_unlock.php", "RESET_ALARMA_SABOTAJE", "Alarma Silenciada")
            Toast.makeText(this, "🔕 Alarma silenciada con éxito", Toast.LENGTH_SHORT).show()
            registrarYNotificar("Alarma sonora desactivada desde la app.")
        }

        // Acción 5: Cerrar Sesión
        btnCerrarSesion.setOnClickListener {
            val intent = Intent(this, LoginActivity::class.java)
            startActivity(intent)
            finish()
        }

        consultarTelemetriaEsp32(tvTemperatura, tvHumedad, tvEstadoPaquete, chipPaquete, tvEstadoSeguridadLDR)
    }

    // 📋 MENÚ DESPLEGABLE PRINCIPAL
    private fun mostrarMenuDesplegableOpciones(tvEstadoVinculacion: TextView, tvPinUsuario: TextView, nombreUsuario: String) {
        val opciones = arrayOf(
            "⚙️ Configuración del Usuario y Casillero",
            "🔔 Notificaciones e Historial de Alertas",
            "📶 Estado de la Configuración Wi-Fi"
        )

        val builder = AlertDialog.Builder(this)
        builder.setTitle("⚙️ Menú de Opciones PorchGuard")
        builder.setItems(opciones) { dialog, which ->
            when (which) {
                0 -> mostrarDialogoConfiguracionUsuario(tvPinUsuario, nombreUsuario)
                1 -> mostrarDialogoNotificaciones()
                2 -> mostrarDialogoEstadoWifi(tvEstadoVinculacion)
            }
            dialog.dismiss()
        }
        builder.setNegativeButton("Cerrar") { dialog, _ -> dialog.dismiss() }
        builder.show()
    }

    // 1️⃣ DIÁLOGO DE CONFIGURACIÓN DEL USUARIO
    private fun mostrarDialogoConfiguracionUsuario(tvPinUsuario: TextView, nombreUsuario: String) {
        val subOpciones = arrayOf(
            "🔑 Modificar PIN de Teclado Físico (Actual: $pinUsuarioLocal)",
            "⏱️ Tiempo Auto-Cierre de Cerradura ($tiempoAutoCierreSegundos seg)",
            "🌡️ Ajustar Temperatura Meta por Defecto",
            "👤 Datos del Usuario ($nombreUsuario)"
        )

        val builder = AlertDialog.Builder(this)
        builder.setTitle("⚙️ Ajustes del Casillero")
        builder.setItems(subOpciones) { dialog, which ->
            when (which) {
                0 -> mostrarDialogoCambiarPinUsuario(tvPinUsuario)
                1 -> cambiarTiempoAutoCierre()
                2 -> cambiarTemperaturaMeta()
                3 -> Toast.makeText(this, "👤 Usuario: $nombreUsuario\nCasillero #$idCasillero", Toast.LENGTH_LONG).show()
            }
            dialog.dismiss()
        }
        builder.setNegativeButton("Atrás") { dialog, _ -> dialog.dismiss() }
        builder.show()
    }

    private fun cambiarTiempoAutoCierre() {
        val tiempos = arrayOf("3 Segundos", "5 Segundos", "10 Segundos")
        val valores = arrayOf(3, 5, 10)
        AlertDialog.Builder(this)
            .setTitle("⏱️ Tiempo de Auto-Cierre")
            .setItems(tiempos) { dialog, which ->
                tiempoAutoCierreSegundos = valores[which]
                sharedPreferences.edit().putInt("TIEMPO_AUTOCIERRE", tiempoAutoCierreSegundos).apply()
                Toast.makeText(this, "⏱️ Auto-cierre fijado en $tiempoAutoCierreSegundos segundos.", Toast.LENGTH_SHORT).show()
                registrarYNotificar("Configuración actualizada: Auto-cierre en $tiempoAutoCierreSegundos seg.")
                dialog.dismiss()
            }.show()
    }

    private fun cambiarTemperaturaMeta() {
        AlertDialog.Builder(this)
            .setTitle("🌡️ Temperatura Meta")
            .setMessage("Define las consignas térmicas por defecto:\n• Modo Caliente: $tempMetaComidaCaliente °C\n• Modo Refrigerado: $tempMetaRefrigerado °C")
            .setPositiveButton("Entendido") { dialog, _ -> dialog.dismiss() }
            .show()
    }

    // 2️⃣ DIÁLOGO DE HISTORIAL DE NOTIFICACIONES
    private fun mostrarDialogoNotificaciones() {
        val builder = AlertDialog.Builder(this)
        builder.setTitle("🔔 Historial de Notificaciones (MySQL)")

        if (listaNotificaciones.isEmpty()) {
            builder.setMessage("No tienes notificaciones recientes.")
        } else {
            val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, listaNotificaciones)
            builder.setAdapter(adapter, null)
        }

        builder.setPositiveButton("Cerrar") { dialog, _ -> dialog.dismiss() }
        builder.setNeutralButton("Limpiar") { _, _ ->
            listaNotificaciones.clear()
            Toast.makeText(this, "Historial borrado localmente", Toast.LENGTH_SHORT).show()
        }
        builder.show()
    }

    // 3️⃣ DIÁLOGO ESTADO DE CONFIGURACIÓN WI-FI
    private fun mostrarDialogoEstadoWifi(tvEstadoVinculacion: TextView) {
        val estadoTexto = if (esWifiConectado) "🟢 CONECTADO" else "🔴 DESCONECTADO"
        val mensaje = "📶 Estado Wi-Fi: $estadoTexto\n" +
                "📡 Red SSID: PorchGuard-Casillero\n" +
                "🌐 Servidor IP: 192.168.1.13\n" +
                "🔑 Token Casillero: $tokenCasilleroActual\n" +
                "📶 Intensidad de Señal: -58 dBm (Excelente)"

        AlertDialog.Builder(this)
            .setTitle("📶 Estado de la Conexión Wi-Fi")
            .setMessage(mensaje)
            .setPositiveButton("Escanear QR") { dialog, _ ->
                abrirCamaraEscaner()
                dialog.dismiss()
            }
            .setNeutralButton("Ajustes Wi-Fi") { dialog, _ ->
                abrirConfiguracionWifi()
                dialog.dismiss()
            }
            .setNegativeButton("Cerrar") { dialog, _ -> dialog.dismiss() }
            .show()
    }

    // 💾 FUNCIONES DE REGISTRO AUTOMÁTICO EN MYSQL
    private fun registrarYNotificar(mensaje: String) {
        val sdf = SimpleDateFormat("HH:mm:ss", Locale.getDefault())
        val horaActual = sdf.format(Date())
        val textoCompleto = "🔔 $horaActual hrs — $mensaje"

        listaNotificaciones.add(0, textoCompleto)
        enviarNotificacionAndroid("PorchGuard IoT", mensaje)

        // Enviar a la tabla historial_notificaciones en MySQL
        guardarNotificacionEnBD(mensaje)
    }

    private fun guardarNotificacionEnBD(mensaje: String) {
        val url = "$urlBaseServer/api_save_notification.php"
        val request = object : StringRequest(
            Request.Method.POST, url,
            { },
            { }
        ) {
            override fun getParams(): MutableMap<String, String> {
                val params = HashMap<String, String>()
                params["titulo"] = "Aviso PorchGuard"
                params["mensaje"] = mensaje
                return params
            }
        }
        Volley.newRequestQueue(this).add(request)
    }

    private fun guardarPinTemporalEnBD(pinCode: String) {
        val url = "$urlBaseServer/api_create_pin.php"
        val request = object : StringRequest(
            Request.Method.POST, url,
            { Toast.makeText(this, "PIN $pinCode guardado en MySQL (pins_temporales)", Toast.LENGTH_SHORT).show() },
            { }
        ) {
            override fun getParams(): MutableMap<String, String> {
                val params = HashMap<String, String>()
                params["pin"] = pinCode
                params["empresa"] = "Chilexpress / Mercado Libre"
                return params
            }
        }
        Volley.newRequestQueue(this).add(request)
    }

    private fun sincronizarTelemetriaConBD() {
        val url = "$urlBaseServer/api_data.php"
        val temp = if (modoTermicoActivo) 38.5 else 8.2
        val request = object : StringRequest(
            Request.Method.POST, url,
            { Toast.makeText(this, "Telemetría guardada en MySQL (historial_telemetria)", Toast.LENGTH_SHORT).show() },
            { }
        ) {
            override fun getParams(): MutableMap<String, String> {
                val params = HashMap<String, String>()
                params["locker"] = tokenCasilleroActual
                params["temp"] = temp.toString()
                params["hum"] = "45"
                params["paquete"] = if (paqueteEnCasillero) "1" else "0"
                params["cerradura"] = if (esCerraduraAbierta) "1" else "0"
                params["modo"] = if (modoTermicoActivo) "CALIENTE" else "REFRIGERADO"
                return params
            }
        }
        Volley.newRequestQueue(this).add(request)
    }

    private fun mostrarDialogoCambiarPinUsuario(tvPinUsuario: TextView) {
        val builder = AlertDialog.Builder(this)
        builder.setTitle("⚙️ Personalizar PIN Teclado Físico")
        builder.setMessage("Ingresa tu nuevo PIN de 4 dígitos para el teclado físico:")

        val input = EditText(this)
        input.inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
        input.hint = "Ejemplo: 1234"
        input.setPadding(32, 24, 32, 24)
        builder.setView(input)

        builder.setPositiveButton("Guardar PIN") { dialog, _ ->
            val nuevoPin = input.text.toString().trim()
            if (nuevoPin.length == 4) {
                pinUsuarioLocal = nuevoPin
                sharedPreferences.edit().putString("PIN_USUARIO_LOCAL", nuevoPin).apply()

                tvPinUsuario.text = "💡 PIN Usuario Teclado Físico: $pinUsuarioLocal"
                Toast.makeText(this, "✅ PIN actualizado a ($nuevoPin). Sincronizado.", Toast.LENGTH_LONG).show()
                registrarYNotificar("PIN de teclado físico actualizado a ($nuevoPin).")
            } else {
                Toast.makeText(this, "⚠️ El PIN debe tener 4 números.", Toast.LENGTH_SHORT).show()
            }
            dialog.dismiss()
        }
        builder.setNegativeButton("Cancelar") { dialog, _ -> dialog.dismiss() }
        builder.show()
    }

    private fun actualizarEstadoWifiUI(tvEstadoVinculacion: TextView, notificar: Boolean) {
        if (esWifiConectado) {
            tvEstadoVinculacion.text = "🟢 Wi-Fi Conectado — PorchGuard #$idCasillero"
            tvEstadoVinculacion.setTextColor(Color.parseColor("#38BDF8"))
        } else {
            tvEstadoVinculacion.text = "🔴 Wi-Fi Desconectado"
            tvEstadoVinculacion.setTextColor(Color.parseColor("#F87171"))
        }
    }

    private fun actualizarEstadoPaqueteUI(tvEstadoPaquete: TextView, chipPaquete: Chip, notificar: Boolean) {
        if (paqueteEnCasillero) {
            tvEstadoPaquete.text = "📦 Paquete guardado dentro del casillero"
            chipPaquete.text = "Recibido"
            chipPaquete.setChipBackgroundColorResource(android.R.color.holo_green_light)
            chipPaquete.setTextColor(Color.parseColor("#065F46"))
            if (notificar) registrarYNotificar("📦 ¡El repartidor ha depositado un nuevo paquete!")
        } else {
            tvEstadoPaquete.text = "📭 Casillero vacío — Aún no llega el paquete"
            chipPaquete.text = "Aún no llega"
            chipPaquete.setChipBackgroundColorResource(android.R.color.holo_orange_light)
            chipPaquete.setTextColor(Color.parseColor("#78350F"))
            if (notificar) registrarYNotificar("📭 Casillero disponible: Esperando paquete.")
        }
        sincronizarTelemetriaConBD()
    }

    private fun mostrarOpcionesVinculacionMenu(tvEstadoVinculacion: TextView) {
        val opciones = arrayOf("📸 Abrir Cámara para Escanear Código QR", "📶 Buscar y Conectar a Red Wi-Fi")
        val builder = AlertDialog.Builder(this)
        builder.setTitle("📷 Vinculación de Casillero IoT")
        builder.setItems(opciones) { dialog, which ->
            when (which) {
                0 -> abrirCamaraEscaner()
                1 -> abrirConfiguracionWifi()
            }
            dialog.dismiss()
        }
        builder.setNegativeButton("Cancelar") { dialog, _ -> dialog.dismiss() }
        builder.show()
    }

    private fun abrirCamaraEscaner() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.CAMERA), CAMERA_REQUEST_CODE)
        } else {
            try {
                val intentCamara = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
                startActivity(intentCamara)
            } catch (e: Exception) {
                Toast.makeText(this, "Abriendo cámara...", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun abrirConfiguracionWifi() {
        try {
            val intentWifi = Intent(Settings.ACTION_WIFI_SETTINGS)
            startActivity(intentWifi)
        } catch (e: Exception) {
            Toast.makeText(this, "Buscando redes...", Toast.LENGTH_SHORT).show()
        }
    }

    private fun enviarNotificacionAndroid(titulo: String, mensaje: String) {
        val builder = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_popup_reminder)
            .setContentTitle(titulo)
            .setContentText(mensaje)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)

        try {
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU ||
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED) {
                val notificationManager = NotificationManagerCompat.from(this)
                notificationManager.notify(System.currentTimeMillis().toInt(), builder.build())
            }
        } catch (e: SecurityException) {
            e.printStackTrace()
        }
    }

    private fun crearCanalNotificaciones() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val canal = NotificationChannel(CHANNEL_ID, "Avisos PorchGuard", NotificationManager.IMPORTANCE_HIGH)
            val notificationManager: NotificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.createNotificationChannel(canal)
        }
    }

    private fun pedirPermisosIniciales() {
        val permisos = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            permisos.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            permisos.add(Manifest.permission.CAMERA)
        }
        if (permisos.isNotEmpty()) {
            ActivityCompat.requestPermissions(this, permisos.toTypedArray(), 101)
        }
    }

    private fun enviarComandoApi(url: String, evento: String, mensajeExito: String) {
        val request = object : StringRequest(
            Request.Method.POST, url,
            { Toast.makeText(this, mensajeExito, Toast.LENGTH_SHORT).show() },
            { }
        ) {
            override fun getParams(): MutableMap<String, String> {
                val params = HashMap<String, String>()
                params["evento"] = evento
                params["metodo"] = "APP_WIFI"
                return params
            }
        }
        Volley.newRequestQueue(this).add(request)
    }

    private fun consultarTelemetriaEsp32(tvTemp: TextView, tvHum: TextView, tvPaquete: TextView, chipPaquete: Chip, tvSeg: TextView) {
        val request = JsonObjectRequest(Request.Method.GET, "$urlBaseServer/api_data.php?locker=$tokenCasilleroActual", null,
            { response ->
                try {
                    val temp = response.optDouble("temperatura", 38.5)
                    val hum = response.optInt("humedad", 45)
                    tvTemp.text = "🌡️ $temp °C"
                    tvHum.text = "💧 Humedad: $hum%"
                } catch (e: Exception) { }
            },
            { }
        )
        Volley.newRequestQueue(this).add(request)
    }
}

