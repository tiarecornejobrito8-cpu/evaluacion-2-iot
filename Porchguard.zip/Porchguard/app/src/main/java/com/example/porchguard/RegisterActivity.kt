
package com.example.porchguard

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.android.volley.Request
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import org.json.JSONObject

class RegisterActivity : AppCompatActivity() {

    private val URL_REGISTER = "http://192.168.1.13/porchguard/register.php"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register)

        val etNombre = findViewById<EditText>(R.id.etNombre)
        val etCorreo = findViewById<EditText>(R.id.etCorreo)
        val etPassword = findViewById<EditText>(R.id.etPassword)
        val btnRegistrar = findViewById<Button>(R.id.btnRegistrar)
        val tvVolverLogin = findViewById<TextView>(R.id.tvVolverLogin)
        val progressBar = findViewById<ProgressBar>(R.id.progressBar)

        tvVolverLogin.setOnClickListener {
            finish()
        }

        btnRegistrar.setOnClickListener {

            val nombre = etNombre.text.toString().trim()
            val correo = etCorreo.text.toString().trim()
            val password = etPassword.text.toString().trim()

            if (nombre.isEmpty() || correo.isEmpty() || password.isEmpty()) {
                Toast.makeText(
                    this,
                    "Por favor completa todos los campos",
                    Toast.LENGTH_SHORT
                ).show()

                return@setOnClickListener
            }

            if (password.length < 8) {
                Toast.makeText(
                    this,
                    "La contraseña debe tener al menos 8 caracteres",
                    Toast.LENGTH_SHORT
                ).show()

                return@setOnClickListener
            }

            progressBar.visibility = View.VISIBLE
            btnRegistrar.isEnabled = false

            val request = object : StringRequest(
                Request.Method.POST,
                URL_REGISTER,

                { response ->

                    progressBar.visibility = View.GONE
                    btnRegistrar.isEnabled = true

                    try {
                        val json = JSONObject(response)

                        if (json.getString("status") == "success") {

                            Toast.makeText(
                                this,
                                "¡Registro exitoso! Por favor inicia sesión",
                                Toast.LENGTH_LONG
                            ).show()

                            val intent = Intent(this, LoginActivity::class.java)
                            startActivity(intent)
                            finish()

                        } else {

                            Toast.makeText(
                                this,
                                json.optString("mensaje", "Error en el registro"),
                                Toast.LENGTH_SHORT
                            ).show()
                        }

                    } catch (e: Exception) {

                        Toast.makeText(
                            this,
                            "Respuesta inválida del servidor",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                },

                { error ->

                    progressBar.visibility = View.GONE
                    btnRegistrar.isEnabled = true

                    val statusCode = error.networkResponse?.statusCode

                    if (statusCode == 409) {

                        Toast.makeText(
                            this,
                            "El correo electrónico ya está registrado",
                            Toast.LENGTH_LONG
                        ).show()

                    } else {

                        Toast.makeText(
                            this,
                            "Error de conexión con el servidor",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                }

            ) {

                override fun getParams(): MutableMap<String, String> {

                    val params = HashMap<String, String>()

                    params["nombre"] = nombre
                    params["correo"] = correo
                    params["password"] = password

                    return params
                }
            }

            Volley.newRequestQueue(this).add(request)
        }
    }
}